package com.goldmansachs.qaagent.model;

public class GeneratedFile {
    private String path;
    private String content;

    // Getters and Setters
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
}
