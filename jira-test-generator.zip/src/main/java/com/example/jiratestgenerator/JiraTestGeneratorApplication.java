package com.example.jiratestgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiraTestGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(JiraTestGeneratorApplication.class, args);
    }
}
